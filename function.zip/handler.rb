def process(event:, context:)
  puts "Does this thing work? #{event}!"
end
